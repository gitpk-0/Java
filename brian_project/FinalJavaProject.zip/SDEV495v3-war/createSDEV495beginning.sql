drop table employees;
drop table items;
drop table roles;
DROP TABLE order_items;
DROP TABLE orders;
DROP TABLE order_status;
DROP TABLE customers;

-- Roles table
CREATE TABLE roles (
  role_id INTEGER PRIMARY KEY,
  role varchar(20) NOT NULL UNIQUE
);

-- Create employees table
CREATE TABLE employees (
  employee_id INTEGER PRIMARY KEY,
  firstname VARCHAR(50) NOT NULL,
  lastname VARCHAR(50) NOT NULL,
  password VARCHAR(40) NOT NULL,
  role_id INTEGER NOT NULL,
  CONSTRAINT FK_ROLE_ID FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE RESTRICT
);

CREATE TABLE items (
  upc VARCHAR(12) NOT NULL PRIMARY KEY,
  brand VARCHAR(50),
  description VARCHAR(50),
  size VARCHAR(50),
  case_size VARCHAR(50)
);

CREATE TABLE customers (
    customer_id INTEGER NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    firstname VARCHAR(50) NOT NULL,
    lastname VARCHAR(50) NOT NULL,
    phone_number VARCHAR(15)
);
CREATE TABLE order_status (
    status VARCHAR(20) NOT NULL PRIMARY KEY,
    requiresAdmin BOOLEAN
);

CREATE TABLE orders(
    order_id INTEGER NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    customer_id INTEGER NOT NULL,
    CONSTRAINT order_customer_id FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);
CREATE TABLE order_items (
    order_id INTEGER NOT NULL,
    CONSTRAINT order_orders_id FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    upc VARCHAR(12) NOT NULL,
    CONSTRAINT pk PRIMARY KEY (order_id, upc),
    quantity INTEGER NOT NULL,
    CHECK ( quantity > 0 ),
    status VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED',
    CONSTRAINT orders_order_status FOREIGN KEY (status) REFERENCES order_status(status) ON DELETE RESTRICT
);

-- Insert roles
INSERT INTO roles (role_id, role)
values (1,'Team Member'),
       (2,'Admin');

-- Insert a user
INSERT INTO employees (employee_id, firstname, lastname, password, role_id)
values (702623, 'Brian', 'Butz', 'password12345', 2),
       (1, 'Test', 'Test', '1', 2),
       (2, 'Team', 'Member', '2', 1);

-- Insert items
INSERT INTO items values (
                          '123456789012',
                          'Test Brand',
                          'This is a test product',
                          'Size = 10',
                          'Case size is 200'
                         );
INSERT INTO items values (
  '450504041234',
  'Organic Valley',
  'Eggnog',
  '32 oz',
  '12/CS'
);
INSERT INTO items values (
  '450504041235',
  'Organic Valley',
  'Whole Milk Ultra Pasteurized',
  '64 oz',
  '6/CS'
);
INSERT INTO items values (
  '450504041236',
  'Organic Valley',
  '2% Milk Ultra Pasteurized',
  '64 oz',
  '6/CS'
);
INSERT INTO items values (
  '450504041237',
  'Organic Valley',
  '1% Milk Ultra Pasteurized',
  '64 oz',
  '6/CS'
);
INSERT INTO items values (
  '450504041238',
  'Organic Valley',
  'Skim Milk Ultra Pasteurized',
  '64 oz',
  '6/CS'
);
INSERT INTO items values (
  '450504041239',
  'Organic Valley',
  'Whole Milk Ultra Pasteurized',
  '32 oz',
  '12/CS'
);
INSERT INTO items values (
  '450504041230',
  'Organic Valley',
  '2% Milk Ultra Pasteurized',
  '32 oz',
  '12/CS'
);
INSERT INTO items values (
  '345678901234',
  'Nature''s Yoke',
  'LG Brown Eggs Pulp',
  '1 DZN',
  '15/CS'
);
INSERT INTO items values (
  '345678901235',
  'Nature''s Yoke',
  'LG Brown Eggs Pasture Raised Pulp',
  '1 DZN',
  '15/CS'
);
INSERT INTO items values (
  '345678901236',
  'Nature''s Yoke',
  'LG Brown Eggs Plastic',
  '1 DZN',
  '15/CS'
);
INSERT INTO items values (
  '345678901237',
  'Nature''s Yoke',
  'Jumbo Eggs Pulp',
  '1 DZN',
  '12/CS'
);
INSERT INTO items values (
  '345678901238',
  'Nature''s Yoke',
  'XL Eggs Pulp',
  '1 DZN',
  '15/CS'
);
INSERT INTO items values (
  '456789012345',
  'Vermont Bread',
  'Honey Whole Wheat',
  '1 Loaf',
  '5/CS'
);
INSERT INTO items values (
  '456789012346',
  'Vermont Bread',
  'White Bread OG',
  '1 Loaf',
  '5/CS'
);
INSERT INTO items values (
  '456789012347',
  'Vermont Bread',
  'Oatmeal Loaf OG',
  '1 Loaf',
  '5/CS'
);
--insert Customers
INSERT INTO customers(firstname, lastname, phone_number)
values ('Test', 'Test', '1234567890');

--insert Statuses
INSERT INTO order_status(status, requiresAdmin)
VALUES ('SUBMITTED', FALSE),
       ('ORDERED', TRUE),
       ('ARRIVED', TRUE),
       ('CUSTOMER_CONTACTED', FALSE),
       ('PICKED_UP', FALSE)

