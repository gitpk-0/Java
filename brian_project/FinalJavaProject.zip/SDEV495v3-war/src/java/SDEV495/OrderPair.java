package SDEV495;

public class OrderPair {
    private final String Brand;
    private final String Description;
    private final String Size;
    private final String caseSize;
    private final String UPC;
    private final int amount;

    public OrderPair(String brand, String description, String size, String casesize, String upc, int amount) {
        this.Brand = brand;
        this.Description = description;
        this.Size = size;
        this.caseSize = casesize;
        UPC = upc;
        this.amount = amount;
    }

    public String getBrand() {
        return Brand;
    }

    public String getDescription() {
        return Description;
    }

    public String getSize() {
        return Size;
    }

    public String getCaseSize() {
        return caseSize;
    }

    public int getAmount() {
        return amount;
    }

    public String getUPC() {
        return UPC;
    }
}
