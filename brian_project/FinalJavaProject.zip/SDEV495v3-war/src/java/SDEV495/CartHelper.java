package SDEV495;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;
import java.util.List;

@WebServlet("/CartHelper")
public class CartHelper extends HttpServlet {
    private static final String CREATE_ORDER_STATEMENT = "INSERT INTO ORDERS (customer_id) VALUES ?";
    private static final String ADD_ORDER_ITEM_STATEMENT =
            "INSERT INTO ORDER_ITEMS (ORDER_ID, UPC, QUANTITY) values (?, ?, ?)";
    private String firstName;
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        System.out.println(action);
        switch (action) {
            case "clear":
                clear(req.getSession());
                break;
            case "submit":
                try {
                    String customerLastName = req.getParameter("lastName");
                    String customerPhone = req.getParameter("phoneNumber");
                    this.firstName = req.getParameter("firstName");
                    //int customerID = Integer.parseInt(req.getParameter("customer"));
                    System.err.println(firstName + " " + customerLastName);
                    submitToDatabase(req.getSession(), Customer.searchOrCreateDBEntry(firstName, customerLastName, customerPhone));
                } catch (SQLException | NumberFormatException throwables) {
                    throwables.printStackTrace();
                }
                break;
        }
        req.getRequestDispatcher("cart.jsp").forward(req, resp);
    }

    public static List<OrderPair> getCart(HttpSession session) {
        //noinspection unchecked Can't do an instanceof on a List<OrderPair>
        return (List<OrderPair>) session.getAttribute("cart");
    }

    public static void addToCart(HttpSession session, OrderPair order) {
        getCart(session).add(order);
    }

    public static boolean submitToDatabase(HttpSession session, Customer customer) {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            conn.setAutoCommit(false);
            PreparedStatement ps = conn.prepareStatement(CREATE_ORDER_STATEMENT, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, customer.getId());
            ps.execute();
            if (!ps.getGeneratedKeys().next()) {
                throw new SQLException("Key for ORDER table failed to generate");
            }
            int orderID = ps.getGeneratedKeys().getInt(1);
            List<OrderPair> cart = getCart(session);

            PreparedStatement items = conn.prepareStatement(ADD_ORDER_ITEM_STATEMENT);
            for (OrderPair op : cart) {
                items.setInt(1, orderID);
                items.setString(2, op.getUPC());
                items.setInt(3, op.getAmount());
                items.execute();
            }

            conn.commit();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
        clear(session);
        return true;
    }

    public static void clear(HttpSession session) {
        getCart(session).clear();
    }
}
