package SDEV495;

import java.sql.*;

public class Customer {
    private static final String CREATE_CUSTOMER_STATEMENT =
            "INSERT INTO customers (firstname, lastname, phone_number) VALUES (?, ?, ?)";
    private static final String LOOKUP_CUSTOMER_STATEMENT = "SELECT * FROM customers WHERE firstname=? and lastname= ?";
    private final String firstName, lastName, phone;
    private final int id;

    public static Customer createDatabaseEntry(String firstName, String lastName, String phone) throws SQLException {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            conn.setAutoCommit(false);
            PreparedStatement ps = conn.prepareStatement(CREATE_CUSTOMER_STATEMENT, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, phone);
            ps.execute();

            conn.commit();
            ResultSet keys = ps.getGeneratedKeys();
            keys.next();
            int id = keys.getInt(1);


            return new Customer(id, firstName, lastName, phone);
        }
    }

    public static Customer searchOrCreateDBEntry(String firstName, String lastName, String phone) throws SQLException {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            conn.setReadOnly(true);
            PreparedStatement ps = conn.prepareStatement(LOOKUP_CUSTOMER_STATEMENT);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                //customer doesn't exist in db
                return createDatabaseEntry(firstName, lastName, phone);
            }
            return new Customer(rs.getInt("CUSTOMER_ID"),
                    rs.getString("FIRSTNAME"),
                    rs.getString("LASTNAME"),
                    rs.getString("PHONE_NUMBER"));
        }
    }

    //Database lookup
    public Customer(String firstName, String lastName, String customerPhone) throws SQLException {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            conn.setReadOnly(true);
            PreparedStatement ps = conn.prepareStatement(LOOKUP_CUSTOMER_STATEMENT);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new IllegalArgumentException("Unable to locate Customer");
            }

            id = rs.getInt(1);
            this.firstName = rs.getString(2);
            this.lastName = rs.getString(3);
            this.phone = rs.getString(4);
        }

        System.err.println(this.toString());
    }

    public Customer(int id, String firstName, String lastName, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phone='" + phone + '\'' +
                ", id=" + id +
                '}';
    }
}
