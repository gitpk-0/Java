package SDEV495;

public class OrderLine {
    private final int orderID, quantity;
    private final String UPC, firstName, lastName, brand, description;
    private final OrderStatus status;

    public OrderLine(int orderID, int quantity, String upc, String firstName, String lastName, String brand, String description, OrderStatus status) {
        this.orderID = orderID;
        this.quantity = quantity;
        UPC = upc;
        this.firstName = firstName;
        this.lastName = lastName;
        this.brand = brand;
        this.description = description;
        this.status = status;
    }

    public int getOrderID() {
        return orderID;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getUPC() {
        return UPC;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDescription() {
        return description;
    }

    public String getBrand() {
        return brand;
    }
}
