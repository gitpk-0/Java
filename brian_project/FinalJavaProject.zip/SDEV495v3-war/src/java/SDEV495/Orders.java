package SDEV495;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/orders")
public class Orders extends HttpServlet {
    private static final String GET_ORDERS_QUERY = "SELECT ORDER_ID, UPC, QUANTITY, STATUS, FIRSTNAME, LASTNAME, BRAND, DESCRIPTION from ORDER_ITEMS INNER JOIN ORDERS USING (ORDER_ID) INNER JOIN CUSTOMERS USING(CUSTOMER_ID) INNER JOIN ITEMS USING(UPC)";
    private static final String GET_STATUSES_QUERY = "SELECT STATUS FROM ORDER_STATUS";
    private static final String UPDATE_STATUS_QUERY = "UPDATE ORDER_ITEMS SET STATUS=? WHERE ORDER_ID=? AND UPC=?";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Authenticate.isLoggedIn(req.getSession())) {
            Authenticate.redirectToLogin(req, resp);
            return;
        }
        int orderID = Integer.parseInt(req.getParameter("orderID"));
        String upc = req.getParameter("UPC");
        String status = req.getParameter("status");
        System.err.println(status +", " + upc + ", " + orderID);
        try(Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            PreparedStatement statement = connection.prepareStatement(UPDATE_STATUS_QUERY);
            statement.setString(1, status);
            statement.setInt(2, orderID);
            statement.setString(3, upc);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return;
        }
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Authenticate.isLoggedIn(req.getSession())) {
            Authenticate.redirectToLogin(req, resp);
            return;
        }
        List<OrderLine> orders = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(GET_ORDERS_QUERY);
            while (resultSet.next()) {
                int orderID = resultSet.getInt("ORDER_ID");
                String upc = resultSet.getString("UPC");
                int quantity = resultSet.getInt("QUANTITY");
                OrderStatus status = OrderStatus.valueOf(resultSet.getString("STATUS"));
                String firstName = resultSet.getString("FIRSTNAME");
                String lastName = resultSet.getString("LASTNAME");
                String brand = resultSet.getString("BRAND");
                String description = resultSet.getString("DESCRIPTION");
                orders.add(new OrderLine(orderID, quantity, upc, firstName, lastName, brand, description, status));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        List<OrderStatus> statuses = new ArrayList<>(OrderStatus.values().length);
        try (Connection connection = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(GET_STATUSES_QUERY);
            while (resultSet.next()) {
                statuses.add(OrderStatus.valueOf(resultSet.getString(1)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        req.setAttribute("results", orders);
        req.setAttribute("statuses", statuses);
        req.getRequestDispatcher("orders.jsp").forward(req, resp);
    }
}
