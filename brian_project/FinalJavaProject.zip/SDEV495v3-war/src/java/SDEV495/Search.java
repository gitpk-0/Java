package SDEV495;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.regex.Pattern;

@WebServlet("/itemSearch")
public class Search extends HttpServlet {
    private static final String UPC_QUERY = "select brand, description, size, case_size from items where upc = ?";
    private static final Pattern UPC_VALIDATION_REGEX = Pattern.compile("[0-9]{12}");

    private static boolean validUPC(String UPC) {
        return UPC_VALIDATION_REGEX.matcher(UPC).matches();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Authenticate.isLoggedIn(req.getSession())) {
            Authenticate.redirectToLogin(req, resp);
            return;
        }
        String Brand = req.getParameter("Brand");
        String UPCToAdd = req.getParameter("UPCToAdd");
        String Description = req.getParameter("Description");
        String Size = req.getParameter("Size");
        String caseSize = req.getParameter("caseSize");
        int quantity;
        try {
            quantity = Integer.parseInt(req.getParameter("QuantityToAdd"));
        } catch (NumberFormatException e) {
            System.err.println("Unable to parse quantity: " + req.getParameter("QuantityToAdd"));
            req.getRequestDispatcher("itemSearch.jsp").forward(req, resp);
            return;
        }
        if (!validUPC(UPCToAdd)) {
            System.err.println("Invalid UPC: " + UPCToAdd);
            req.getRequestDispatcher("itemSearch.jsp").forward(req, resp);
            return;
        }

        CartHelper.addToCart(req.getSession(), new OrderPair(Brand, Description, Size, caseSize, UPCToAdd, quantity));

        req.getRequestDispatcher("itemSearch.jsp").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Authenticate.isLoggedIn(req.getSession())) {
            Authenticate.redirectToLogin(req, resp);
            return;
        }
        String UPCreq = req.getParameter("UPC");
        if (!validUPC(UPCreq)) {
            System.err.println("Illegal UPC search requested: " + UPCreq);
            req.getRequestDispatcher("itemSearch.jsp").forward(req, resp);
            return;
        }

        StringBuilder sb = new StringBuilder();
        try (Connection conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/SDEV495;",
                "sdev495",
                "sdev495")) {
            conn.setReadOnly(true);

            PreparedStatement ps = conn.prepareStatement(UPC_QUERY);
            ps.setString(1, UPCreq);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                sb.append(String.format(
                        "<tr>\n" +
                                "    <td>%s</td>\n" +
                                "    <td>%s</td>\n" +
                                "    <td>%s</td>\n" +
                                "    <td>%s</td" +
                                ">\n" +
                                "    " +
                                "<td>\n" +
                                "        <form action='itemSearch' method='post'>\n" +
                                "            <input type='text' id='Brand' name='Brand' value='%s' hidden>\n" +
                                "            <input type='text' id='Description' name='Description' value='%s' hidden>\n" +
                                "            <input type='text' id='Size' name='Size' value='%s' hidden>\n" +
                                "            <input type='text' id='caseSize' name='caseSize' value='%s' hidden>\n" +
                                "            <input type='text' id='UPCToAdd' name='UPCToAdd' value='%s' hidden>\n" +
                                "            <input type='number' id='QuantityToAdd' name='QuantityToAdd' min='0' value='1'>\n" +
                                "            <input class=\"btn btn-dark\" type='submit' name='submitBtn' value='Add Item'" +
                                ">\n" +
                                "        </form>\n" +
                                "    </td>\n" +
                                "</tr>\n",
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4), UPCreq));
            }
        } catch (SQLException throwables) {
            System.err.println(throwables.toString());
        }

        req.setAttribute("results", sb.toString());
        req.getRequestDispatcher("itemSearch.jsp").forward(req, resp);
    }
}
