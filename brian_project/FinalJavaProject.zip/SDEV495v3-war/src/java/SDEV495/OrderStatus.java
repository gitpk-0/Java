package SDEV495;

public enum OrderStatus {
    SUBMITTED(false),
    ORDERED(true),
    ARRIVED(true),
    CUSTOMER_CONTACTED(false),
    PICKED_UP(false)
    ;

    private final boolean requiresAdmin;

    OrderStatus(boolean requiresAdmin) {
        this.requiresAdmin = requiresAdmin;
    }

    public boolean requiresAdmin() {
        return requiresAdmin;
    }
}
